import { Component } from '@angular/core';

@Component({
  selector: 'ngx-not-found',
  styleUrls: ['./not-found.component.less'],
  templateUrl: './not-found.component.html',
})
export class NotFoundComponent {

  goToHome() {
    
  }
}
