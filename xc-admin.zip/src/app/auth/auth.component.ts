import { Component } from '@angular/core';

@Component({
  selector: 'ngx-auth',
  styleUrls: ['auth.component.less'],
  templateUrl: './auth.component.html',
})
export class AuthComponent {
  copyRightText = 'Copyright©2021-2022 建设单位：相城区信息中心';
}
